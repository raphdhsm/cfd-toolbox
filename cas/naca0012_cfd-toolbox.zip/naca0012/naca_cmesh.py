#!/usr/bin/env python3
r"""
naca_cmesh.py — Maillage structuré en C autour d'un profil NACA 4 chiffres, écrit
directement au format OpenFOAM (constant/polyMesh). Compatible Foundation et ESI.

Pourquoi pas blockMesh ? Avec blockMesh, les lignes de maillage près de la paroi
visent le point correspondant du champ lointain (interpolation transfinie), ce
qui donne des cellules de paroi très non orthogonales au bord d'attaque. Ici, le
script construit chaque ligne « normale » lui-même : elle part perpendiculaire à
la paroi, puis s'incurve en douceur vers la frontière lointaine.

Topologie (vue de côté) :

        farfield (demi-cercle centré au bord de fuite + lignes droites y = ±R)
      ____________________________________________
     /                                            |
    (    profil  >=============== ligne de sillage |  outlet
     \____________________________________________|

Exemples :
    python3 naca_cmesh.py                         # NACA 0012 « NASA », Re = 6e6
    python3 naca_cmesh.py --naca 4412 --re 1e6    # profil cambré, régime foil
    python3 naca_cmesh.py --n-airfoil 256 --n-wake 128 --out raffine

Le dossier de sortie reçoit constant/polyMesh/ + un PNG du maillage + les
coordonnées du profil. Lancer ensuite `checkMesh` dans ce dossier.
"""

import argparse
import math
import os

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq


# --------------------------------------------------------------------------
# 1. Géométrie du profil
# --------------------------------------------------------------------------
def naca4_surfaces(code, sharp_te=True, tmr=False, n_dense=4001):
    """Renvoie (upper, lower) : tableaux (n, 2) du bord d'attaque au bord de fuite."""
    m = int(code[0]) / 100.0
    p = int(code[1]) / 10.0
    t = int(code[2:]) / 100.0

    beta = np.linspace(0.0, math.pi, n_dense)
    x = 0.5 * (1.0 - np.cos(beta))  # resserré aux deux bords

    if tmr:
        # NACA 0012 à bord de fuite pointu, définition exacte du NASA TMR
        if code != "0012":
            raise ValueError("--tmr n'existe que pour le NACA 0012")
        yt = 0.594689181 * (0.298222773 * np.sqrt(x) - 0.127125232 * x
                            - 0.357907906 * x**2 + 0.291984971 * x**3
                            - 0.105174606 * x**4)
    else:
        a4 = -0.1036 if sharp_te else -0.1015
        yt = 5 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2
                      + 0.2843 * x**3 + a4 * x**4)

    if m == 0:
        yc = np.zeros_like(x)
        dyc = np.zeros_like(x)
    else:
        yc = np.where(x < p, m / p**2 * (2 * p * x - x**2),
                      m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc = np.where(x < p, 2 * m / p**2 * (p - x),
                       2 * m / (1 - p)**2 * (p - x))
    th = np.arctan(dyc)
    upper = np.column_stack([x - yt * np.sin(th), yc + yt * np.cos(th)])
    lower = np.column_stack([x + yt * np.sin(th), yc - yt * np.cos(th)])
    return upper, lower


class Curve:
    """Courbe paramétrée par l'abscisse curviligne (splines cubiques)."""

    def __init__(self, pts):
        seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        s = np.concatenate([[0.0], np.cumsum(seg)])
        self.length = s[-1]
        self.sx = CubicSpline(s, pts[:, 0])
        self.sy = CubicSpline(s, pts[:, 1])

    def point(self, s):
        return np.column_stack([self.sx(s), self.sy(s)])

    def tangent(self, s):
        t = np.column_stack([self.sx(s, 1), self.sy(s, 1)])
        return t / np.linalg.norm(t, axis=1)[:, None]


# --------------------------------------------------------------------------
# 2. Lois de répartition 1D
# --------------------------------------------------------------------------
def two_sided_tanh(n, ds0, ds1):
    """n intervalles sur [0, 1], premier pas ds0 et dernier pas ds1 (Vinokur)."""
    b = 1.0 / (n * math.sqrt(ds0 * ds1))
    if b <= 1.0:
        raise ValueError("pas imposés trop grands pour ce nombre de mailles")
    delta = brentq(lambda d: math.sinh(d) / d - b, 1e-8, 100.0)
    a = math.sqrt(ds1 / ds0)
    xi = np.linspace(0.0, 1.0, n + 1)
    u = 0.5 * (1.0 + np.tanh(delta * (xi - 0.5)) / math.tanh(delta / 2.0))
    s = u / (a + (1.0 - a) * u)
    return s


def geometric(n, ds0, length):
    """n intervalles géométriques, premier pas ds0, longueur totale imposée."""
    if ds0 * n >= length:
        raise ValueError("premier pas trop grand pour la longueur demandée")
    r = brentq(lambda r: ds0 * (r**n - 1.0) / (r - 1.0) - length, 1.0 + 1e-10, 3.0)
    return np.concatenate([[0.0], np.cumsum(ds0 * r ** np.arange(n))]), r


def stretch_fill(n, ds0, length):
    """n pas géométriques, premier pas ds0, somme = length (raison libre)."""
    k = np.arange(n)
    r = brentq(lambda r: ds0 * np.sum(r ** k) - length, 0.5, 3.0)
    return ds0 * r ** k


# --------------------------------------------------------------------------
# 3. Construction de la grille structurée (i le long du C, j vers l'extérieur)
# --------------------------------------------------------------------------
def build_grid(a):
    upper, lower = naca4_surfaces(a.naca, sharp_te=not a.blunt_te, tmr=a.tmr)
    cu, cl = Curve(upper), Curve(lower)

    # --- ligne j = 0 : sillage bas -> intrados -> extrados -> sillage haut
    s_lo = (1.0 - two_sided_tanh(a.n_airfoil, a.ds_te / cl.length,
                                 a.ds_le / cl.length)) * cl.length  # BF -> BA
    s_up = two_sided_tanh(a.n_airfoil, a.ds_le / cu.length,
                          a.ds_te / cu.length) * cu.length          # BA -> BF
    p_lo, p_up = cl.point(s_lo), cu.point(s_up)
    t_lo, t_up = -cl.tangent(s_lo), cu.tangent(s_up)  # sens de parcours

    x_te = 0.5 * (upper[-1, 0] + lower[-1, 0])
    y_te = 0.5 * (upper[-1, 1] + lower[-1, 1])
    xw, r_wake = geometric(a.n_wake, a.ds_te, a.wake_length)
    wake = np.column_stack([x_te + xw, np.full_like(xw, y_te)])

    wall = np.vstack([wake[::-1], p_lo[1:], p_up[1:], wake[1:]])
    tang = np.vstack([np.tile([-1.0, 0.0], (a.n_wake, 1)), t_lo[:-1],
                      [[0.0, 1.0]], t_up[1:],
                      np.tile([1.0, 0.0], (a.n_wake, 1))])
    ni = len(wall)
    i_te_lo = a.n_wake
    i_te_up = ni - 1 - a.n_wake

    # --- direction de départ : normale à la paroi, rendue monotone pour que
    #     les lignes ne se croisent pas près du bord de fuite
    normal = np.column_stack([-tang[:, 1], tang[:, 0]])
    ang = np.degrees(np.arctan2(normal[:, 1], normal[:, 0])) % 360.0
    ang[:i_te_lo + 1] = 270.0
    ang[i_te_up:] = 90.0
    ang = np.clip(ang, 90.0, 270.0)
    ang = np.minimum.accumulate(ang)
    d0 = np.column_stack([np.cos(np.radians(ang)), np.sin(np.radians(ang))])

    # --- points sur la frontière lointaine
    R = a.farfield
    seg = np.linalg.norm(np.diff(wall[i_te_lo:i_te_up + 1], axis=0), axis=1)
    f = np.concatenate([[0.0], np.cumsum(seg)]) / seg.sum()
    th_out = 0.5 * ang[i_te_lo:i_te_up + 1] + 0.5 * (270.0 - 180.0 * f)
    outer = np.empty_like(wall)
    d1 = np.empty_like(wall)
    rad = np.radians(th_out)
    outer[i_te_lo:i_te_up + 1] = np.column_stack(
        [x_te + R * np.cos(rad), y_te + R * np.sin(rad)])
    d1[i_te_lo:i_te_up + 1] = np.column_stack([np.cos(rad), np.sin(rad)])
    # sur les bords haut/bas du sillage, on reprend le pas de l'arc au droit du
    # bord de fuite : les lignes s'écartent progressivement au lieu de rester
    # serrées à 1e-3 jusqu'au champ lointain (sinon cellules très non orthogonales)
    ds_far = 0.5 * (np.linalg.norm(outer[i_te_up] - outer[i_te_up - 1])
                    + np.linalg.norm(outer[i_te_lo] - outer[i_te_lo + 1]))
    xo, _ = geometric(a.n_wake, ds_far, a.wake_length)
    outer[:i_te_lo] = np.column_stack([x_te + xo[::-1][:-1], np.full(i_te_lo, y_te - R)])
    d1[:i_te_lo] = [0.0, -1.0]
    outer[i_te_up + 1:] = np.column_stack([x_te + xo[1:], np.full(ni - i_te_up - 1, y_te + R)])
    d1[i_te_up + 1:] = [0.0, 1.0]

    # --- répartition en j : couche limite (y1, r) puis étirement r2 jusqu'à R
    n_bl = a.n_bl
    ds_bl = a.y1 * a.growth ** np.arange(n_bl)
    h_bl = ds_bl.sum()
    ds_next = ds_bl[-1] * a.growth
    if getattr(a, "n_out", None):
        n_out = a.n_out           # imposé par --level (raffinement systématique)
    else:
        n_out = math.ceil(math.log(1 + (R - h_bl) * (a.growth_outer - 1) / ds_next)
                          / math.log(a.growth_outer))
    nj = n_bl + n_out + 1

    # --- chaque ligne i : courbe de Hermite (départ normal, arrivée radiale)
    grid = np.empty((ni, nj, 2))
    tt = np.linspace(0.0, 1.0, 3001)
    h00, h10 = 2 * tt**3 - 3 * tt**2 + 1, tt**3 - 2 * tt**2 + tt
    h01, h11 = -2 * tt**3 + 3 * tt**2, tt**3 - tt**2
    # dans le sillage, la 1re maille grossit avec la distance au bord de fuite
    # (limite l'allongement des cellules loin en aval)
    scale = 1.0 + a.wake_y1_growth * np.maximum(wall[:, 0] - x_te, 0.0)
    scale[i_te_lo:i_te_up + 1] = 1.0
    for i in range(ni):
        L = np.linalg.norm(outer[i] - wall[i])
        k = a.tangent_factor * L
        c = (h00[:, None] * wall[i] + h10[:, None] * k * d0[i]
             + h01[:, None] * outer[i] + h11[:, None] * k * d1[i])
        sc = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(c, axis=0), axis=1))])
        bl = ds_bl * scale[i]
        ds_out = stretch_fill(n_out, bl[-1] * a.growth, sc[-1] - bl.sum())
        sj = np.concatenate([[0.0], np.cumsum(np.concatenate([bl, ds_out]))])
        grid[i, :, 0] = np.interp(sj, sc, c[:, 0])
        grid[i, :, 1] = np.interp(sj, sc, c[:, 1])

    info = dict(ni=ni, nj=nj, i_te_lo=i_te_lo, i_te_up=i_te_up, n_bl=n_bl,
                h_bl=h_bl, r_wake=r_wake, x_te=x_te, upper=upper, lower=lower)
    return grid, info


# --------------------------------------------------------------------------
# 4. Écriture du polyMesh OpenFOAM
# --------------------------------------------------------------------------
def foam_header(cls, obj, note=None):
    s = ("FoamFile\n{\n    version     2.0;\n    format      ascii;\n    class       %s;\n" % cls)
    if note:
        s += '    note        "%s";\n' % note
    s += "    location    \"constant/polyMesh\";\n    object      %s;\n}\n\n" % obj
    return s


def write_polymesh(grid, info, dz, outdir):
    ni, nj = info["ni"], info["nj"]
    nw = info["i_te_lo"]
    # identifiants 2D, avec fusion des points de la coupure de sillage
    pid = -np.ones((ni, nj), dtype=np.int64)
    n = 0
    for i in range(ni):
        for j in range(nj):
            if j == 0 and i >= ni - 1 - nw:
                pid[i, j] = pid[ni - 1 - i, 0]
            else:
                pid[i, j] = n
                n += 1
    n2d = n
    pts2d = np.empty((n2d, 2))
    pts2d[pid.ravel()] = grid.reshape(-1, 2)

    nci, ncj = ni - 1, nj - 1
    cid = np.arange(nci * ncj).reshape(nci, ncj)
    cc = 0.25 * (grid[:-1, :-1] + grid[1:, :-1] + grid[:-1, 1:] + grid[1:, 1:])
    cc = cc.reshape(-1, 2)

    internal, patches = [], {"airfoil": [], "farfield": [], "outlet": [],
                             "frontAndBack": []}

    def edge_face(a2, b2):
        return [a2, b2, b2 + n2d, a2 + n2d]

    # faces le long de j (lignes i = cte)
    for i in range(ni):
        for j in range(ncj):
            f = edge_face(pid[i, j], pid[i, j + 1])
            if 0 < i < ni - 1:
                internal.append((cid[i - 1, j], cid[i, j], f))
            else:
                patches["outlet"].append((cid[min(i, nci - 1), j], f))
    # faces le long de i (lignes j = cte)
    for i in range(nci):
        for j in range(nj):
            f = edge_face(pid[i, j], pid[i + 1, j])
            if 0 < j < nj - 1:
                internal.append((cid[i, j - 1], cid[i, j], f))
            elif j == nj - 1:
                patches["farfield"].append((cid[i, ncj - 1], f))
            elif nw <= i < ni - 1 - nw:
                patches["airfoil"].append((cid[i, 0], f))
            elif i < nw:  # coupure de sillage : face interne, comptée une fois
                internal.append((cid[i, 0], cid[nci - 1 - i, 0], f))
    # faces avant / arrière (2D)
    for i in range(nci):
        for j in range(ncj):
            q = [pid[i, j], pid[i + 1, j], pid[i + 1, j + 1], pid[i, j + 1]]
            patches["frontAndBack"].append((cid[i, j], q))
            patches["frontAndBack"].append((cid[i, j], [v + n2d for v in q]))

    pts3d = np.vstack([np.column_stack([pts2d, np.zeros(n2d)]),
                       np.column_stack([pts2d, np.full(n2d, dz)])])
    ccz = np.column_stack([cc, np.full(len(cc), 0.5 * dz)])

    def orient(face, target):
        """Retourne la face pour que sa normale pointe vers `target`."""
        p = pts3d[face]
        nrm = np.cross(p[2] - p[0], p[3] - p[1])
        if np.dot(nrm, target - p.mean(axis=0)) < 0:
            face = face[::-1]
        return face

    faces, owner, neigh = [], [], []
    internal = [(min(o, nb), max(o, nb), f) for o, nb, f in internal]
    internal.sort(key=lambda x: (x[0], x[1]))
    for o, nb, f in internal:
        faces.append(orient(f, ccz[nb]))
        owner.append(o)
        neigh.append(nb)
    n_internal = len(faces)
    bounds = []
    for name in ["airfoil", "farfield", "outlet", "frontAndBack"]:
        start = len(faces)
        for o, f in patches[name]:
            away = 2 * pts3d[f].mean(axis=0) - ccz[o]
            faces.append(orient(f, away))
            owner.append(o)
        bounds.append((name, len(faces) - start, start))

    d = os.path.join(outdir, "constant", "polyMesh")
    os.makedirs(d, exist_ok=True)
    note = "nPoints:%d  nCells:%d  nFaces:%d  nInternalFaces:%d" % (
        len(pts3d), nci * ncj, len(faces), n_internal)
    with open(os.path.join(d, "points"), "w") as fh:
        fh.write(foam_header("vectorField", "points"))
        fh.write("%d\n(\n" % len(pts3d))
        fh.writelines("(%.12g %.12g %.12g)\n" % tuple(p) for p in pts3d)
        fh.write(")\n")
    with open(os.path.join(d, "faces"), "w") as fh:
        fh.write(foam_header("faceList", "faces"))
        fh.write("%d\n(\n" % len(faces))
        fh.writelines("4(%d %d %d %d)\n" % tuple(f) for f in faces)
        fh.write(")\n")
    for name, data in [("owner", owner), ("neighbour", neigh)]:
        with open(os.path.join(d, name), "w") as fh:
            fh.write(foam_header("labelList", name, note))
            fh.write("%d\n(\n" % len(data))
            fh.writelines("%d\n" % v for v in data)
            fh.write(")\n")
    types = {"airfoil": "wall", "farfield": "patch", "outlet": "patch",
             "frontAndBack": "empty"}
    with open(os.path.join(d, "boundary"), "w") as fh:
        fh.write(foam_header("polyBoundaryMesh", "boundary"))
        fh.write("%d\n(\n" % len(bounds))
        for name, nf, start in bounds:
            extra = "        inGroups        List<word> 1(wall);\n" if types[name] == "wall" else ""
            fh.write("    %s\n    {\n        type            %s;\n%s"
                     "        nFaces          %d;\n        startFace       %d;\n    }\n"
                     % (name, types[name], extra, nf, start))
        fh.write(")\n")
    return nci * ncj


# --------------------------------------------------------------------------
# 5. Contrôles rapides et figure
# --------------------------------------------------------------------------
def quality(grid):
    a, b, c, d = grid[:-1, :-1], grid[1:, :-1], grid[1:, 1:], grid[:-1, 1:]
    area = 0.5 * ((c - a)[..., 0] * (d - b)[..., 1] - (c - a)[..., 1] * (d - b)[..., 0])
    ei = np.linalg.norm(b - a, axis=-1)
    ej = np.linalg.norm(d - a, axis=-1)
    # angle à la paroi entre ligne i (le long de la paroi) et ligne j
    vi, vj = b - a, d - a
    cosang = np.abs((vi * vj).sum(-1)) / (ei * ej)
    skew_wall = np.degrees(np.arcsin(np.clip(cosang[:, 0], 0, 1)))
    return area.min(), (np.maximum(ei, ej) / np.minimum(ei, ej)).max(), skew_wall


def plot(grid, info, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    views = [("Domaine complet", None),
             ("Bord d'attaque", (-0.03, 0.05, -0.04, 0.04)),
             ("Bord de fuite", (0.97, 1.03, -0.03, 0.03)),
             ("Profil entier", (-0.1, 1.2, -0.35, 0.35))]
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))
    for ax, (title, lim) in zip(axs.ravel(), views):
        step = 4 if lim is None else 1
        for i in range(0, grid.shape[0], step):
            ax.plot(grid[i, :, 0], grid[i, :, 1], "k-", lw=0.25)
        for j in range(0, grid.shape[1], step):
            ax.plot(grid[:, j, 0], grid[:, j, 1], "k-", lw=0.25)
        ax.plot(info["upper"][:, 0], info["upper"][:, 1], "r-", lw=1)
        ax.plot(info["lower"][:, 0], info["lower"][:, 1], "r-", lw=1)
        ax.set_aspect("equal")
        ax.set_title(title)
        if lim:
            ax.set_xlim(lim[:2]); ax.set_ylim(lim[2:])
    fig.tight_layout()
    fig.savefig(path, dpi=130)


# --------------------------------------------------------------------------
# 6. Raffinement systématique (étude de convergence en maillage)
# --------------------------------------------------------------------------
def apply_level(a):
    """Transforme les paramètres du niveau 0 en ceux du niveau a.level.

    Chaque niveau divise (ou fusionne) les mailles par 2 dans toutes les
    directions :
      - le long du profil et du sillage : 2x plus de mailles, pas extrêmes / 2 ;
      - normalement à la paroi : n mailles de raison r' = r**(1/n) remplacent
        exactement une maille de raison r, avec y1' = y1 (r' - 1) / (r - 1).
    """
    f = 2.0 ** a.level
    # nombre de mailles hors couche limite au niveau 0, à conserver en proportion
    R = a.farfield
    h_bl = a.y1 * (a.growth ** a.n_bl - 1) / (a.growth - 1)
    ds_next = a.y1 * a.growth ** a.n_bl
    n_out0 = math.ceil(math.log(1 + (R - h_bl) * (a.growth_outer - 1) / ds_next)
                       / math.log(a.growth_outer))

    g_new = a.growth ** (1.0 / f)
    a.y1 = a.y1 * (g_new - 1.0) / (a.growth - 1.0)
    a.growth = g_new
    a.growth_outer = a.growth_outer ** (1.0 / f)
    a.n_bl = max(1, int(round(a.n_bl * f)))
    a.n_out = max(1, int(round(n_out0 * f)))
    a.n_airfoil = max(4, int(round(a.n_airfoil * f)))
    a.n_wake = max(2, int(round(a.n_wake * f)))
    a.ds_le /= f
    a.ds_te /= f


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--naca", default="0012", help="code NACA 4 chiffres")
    ap.add_argument("--tmr", action="store_true",
                    help="NACA 0012 exact du NASA TMR (activé par défaut pour 0012)")
    ap.add_argument("--no-tmr", action="store_true", help="formule NACA standard")
    ap.add_argument("--blunt-te", action="store_true",
                    help="bord de fuite épais d'origine (non géré par la topologie en C)")
    ap.add_argument("--re", type=float, default=6e6, help="Reynolds sur la corde")
    ap.add_argument("--yplus", type=float, default=0.5,
                    help="y+ visé au centre de la 1re maille (estimation plaque plane)")
    ap.add_argument("--y1", type=float, help="hauteur de la 1re maille (écrase --yplus)")
    ap.add_argument("--growth", type=float, default=1.1, help="taux de croissance dans la CL")
    ap.add_argument("--growth-outer", type=float, default=1.15,
                    help="taux de croissance au-delà de la CL")
    ap.add_argument("--n-bl", type=int, help="nombre de couches (défaut : couvrir delta)")
    ap.add_argument("--n-airfoil", type=int, default=128, help="mailles par face du profil")
    ap.add_argument("--n-wake", type=int, default=64, help="mailles dans le sillage")
    ap.add_argument("--ds-le", type=float, default=1e-3, help="pas au bord d'attaque")
    ap.add_argument("--ds-te", type=float, default=1e-3, help="pas au bord de fuite")
    ap.add_argument("--farfield", type=float, default=50.0, help="rayon du domaine (cordes)")
    ap.add_argument("--wake-length", type=float, default=50.0, help="longueur du sillage")
    ap.add_argument("--wake-y1-growth", type=float, default=0.0,
                    help="croissance de la 1re maille dans le sillage, par corde (0 = constante)")
    ap.add_argument("--dz", type=float, default=0.1, help="épaisseur de la tranche 2D")
    ap.add_argument("--tangent-factor", type=float, default=0.5,
                    help="raideur des lignes j (avancé)")
    ap.add_argument("--level", type=int, default=0,
                    help="niveau de raffinement systématique : -1 grossier, 0 moyen, +1 fin "
                         "(facteur 2 par niveau dans toutes les directions)")
    ap.add_argument("--out", default="naca_mesh", help="dossier de sortie (cas OpenFOAM)")
    a = ap.parse_args()
    a.tmr = (a.naca == "0012" and not a.no_tmr) or a.tmr

    # estimation plaque plane (mêmes formules qu'à la main)
    cf = 0.0592 * a.re ** -0.2
    nu = 1.0 / a.re                      # c = 1 m, U = 1 m/s
    utau = math.sqrt(cf / 2.0)
    if a.y1 is None:
        a.y1 = 2.0 * a.yplus * nu / utau  # hauteur = 2 x distance au centre
    delta = 0.37 * a.re ** -0.2
    if a.n_bl is None:
        a.n_bl = math.ceil(math.log(1 + delta * (a.growth - 1) / a.y1) / math.log(a.growth))

    if a.level != 0:
        apply_level(a)

    grid, info = build_grid(a)
    ncells = write_polymesh(grid, info, a.dz, a.out)
    amin, armax, skew = quality(grid)
    np.savetxt(os.path.join(a.out, "profil_NACA%s.dat" % a.naca),
               np.vstack([info["upper"][::-1], info["lower"][1:]]), fmt="%.8f")
    plot(grid, info, os.path.join(a.out, "maillage_NACA%s.png" % a.naca))

    names = {-2: "très grossier", -1: "grossier", 0: "moyen", 1: "fin", 2: "très fin"}
    print("NACA %s%s  |  Re = %.3g  ->  nu = %.4g m2/s (c = 1 m, U = 1 m/s)"
          % (a.naca, " (TMR)" if a.tmr else "", a.re, nu))
    print("Niveau %+d (%s) : %d mailles/face, %d dans le sillage, pas BA/BF %.2g / %.2g, "
          "croissance CL %.4f, au-delà %.4f"
          % (a.level, names.get(a.level, "?"), a.n_airfoil, a.n_wake, a.ds_le, a.ds_te,
             a.growth, a.growth_outer))
    print("Cf = %.5f  u_tau = %.5f  ->  1re maille y1 = %.3g m (y+ ~ %.2g au centre)"
          % (cf, utau, a.y1, a.y1 / 2 * utau / nu))
    print("delta = %.4f m  ->  %d couches (r = %.2f), épaisseur couverte %.4f m"
          % (delta, a.n_bl, a.growth, info["h_bl"]))
    print("Grille : %d x %d points, %d cellules | sillage r = %.3f"
          % (info["ni"], info["nj"], ncells, info["r_wake"]))
    print("Aire mini = %.3g (doit être > 0) | AR maxi = %.3g | angle à la paroi : "
          "max %.1f°, moyen %.1f° (0° = orthogonal)"
          % (amin, armax, skew.max(), skew.mean()))
    print("Aref pour forceCoeffs : c x dz = %.4g m2" % a.dz)


if __name__ == "__main__":
    main()
