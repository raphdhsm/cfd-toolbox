#!/usr/bin/env python3
r"""
domaine_naca.py — Sensibilité des coefficients à la taille du domaine de calcul.

Un profil porteur crée une perturbation de vitesse qui ne décroît qu'en 1/r.
Une frontière lointaine placée à une distance R impose l'écoulement uniforme
« trop tôt », ce qui fausse surtout la portance, avec une erreur qui varie
à peu près comme c/R. Le script :
  1. lit Cl et Cd de chaque cas (valeur convergée en itérations, même méthode
     que gci_naca.py : médiane de la fin du calcul, ou extrapolation si le
     coefficient dérive encore) ;
  2. trace Cl et Cd en fonction de c/R ;
  3. extrapole à R infini avec une loi linéaire en 1/R (sur les deux plus grands
     domaines) et donne l'erreur due au domaine pour chaque taille.

Utilisation (depuis le dossier NACA0012/) :
    python3 domaine_naca.py 25:naca0012_R25 50:naca0012_re6e6 100:naca0012_R100

Chaque argument est « rayon_en_cordes:dossier_du_cas ».
Ce script importe post_naca.py et gci_naca.py : les trois fichiers doivent
être dans le même dossier.
"""

import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import post_naca as pn  # noqa: E402
from gci_naca import converged_value  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cases", nargs="+", help="R:dossier (au moins deux)")
    ap.add_argument("--block", type=int, default=2000,
                    help="taille des blocs d'itérations pour juger la dérive")
    ap.add_argument("--out", default="sensibilite_domaine.png", help="figure de sortie")
    a = ap.parse_args()

    R, vals = [], {"Cl": [], "Cd": []}
    print("\n=== Valeurs convergées en itérations ===\n")
    for item in a.cases:
        r, case = item.split(":", 1)
        case = os.path.abspath(os.path.expanduser(case))
        hdr, rows = pn.load_function_object(case, "forceCoeffs")
        if hdr is None:
            sys.exit("Pas de forceCoeffs dans %s" % case)
        it = pn.column(hdr, rows, "Time")
        R.append(float(r))
        print("R = %5.0f cordes  (%s, %d itérations)" % (float(r), os.path.basename(case), it[-1]))
        for coef in ["Cl", "Cd"]:
            v, how, _ = converged_value(it, pn.column(hdr, rows, coef), a.block)
            vals[coef].append(v)
            print("   %s = %.5f   [%s]" % (coef, v, how))
    order = np.argsort(R)
    R = np.array(R)[order]
    x = 1.0 / R
    for coef in vals:
        vals[coef] = np.array(vals[coef])[order]

    print("\n=== Extrapolation à domaine infini (loi en 1/R, deux plus grands domaines) ===\n")
    ext = {}
    for coef in ["Cl", "Cd"]:
        y = vals[coef]
        slope = (y[-1] - y[-2]) / (x[-1] - x[-2])
        ext[coef] = y[-1] - slope * x[-1]
        print("%s à R infini : %.5f" % (coef, ext[coef]))
        for r, v in zip(R, y):
            print("   R = %5.0f : %.5f  ->  erreur due au domaine %+.2f %%"
                  % (r, v, 100 * (v - ext[coef]) / ext[coef]))
        print()

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.grid": True, "grid.alpha": 0.3,
                         "axes.spines.top": False, "axes.spines.right": False})
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.8))
    fig.suptitle("Sensibilité à la taille du domaine", fontsize=13, fontweight="bold")
    for ax, coef, col in zip(axs, ["Cl", "Cd"], ["#1f5fa8", "#c0392b"]):
        y = vals[coef]
        ax.plot(x, y, "o-", color=col, ms=7, label="OpenFOAM (k-ω SST)")
        for xi, yi, r in zip(x, y, R):
            ax.annotate("R = %g c" % r, (xi, yi), textcoords="offset points",
                        xytext=(6, 6), fontsize=8)
        xx = np.linspace(0, x.max() * 1.05, 50)
        slope = (y[-1] - y[-2]) / (x[-1] - x[-2])
        ax.plot(xx, ext[coef] + slope * xx, "--", color="grey", lw=1, label="loi en 1/R")
        ax.plot([0], [ext[coef]], "s", color="k", ms=7, label="R infini (extrapolé)")
        ax.set_xlabel("c / R")
        ax.set_ylabel("$C_l$" if coef == "Cl" else "$C_d$")
        ax.set_title("Portance" if coef == "Cl" else "Traînée")
        ax.legend(fontsize=8)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(a.out, dpi=140)
    print("Figure : %s\n" % os.path.abspath(a.out))


if __name__ == "__main__":
    main()
