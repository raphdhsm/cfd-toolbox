#!/usr/bin/env python3
r"""
cp_cf_naca.py — Distributions de pression (Cp) et de frottement (Cf) le long du
profil, pour quelques incidences de la polaire, avec repérage du décollement.

Pour chaque angle demandé, le script :
  1. calcule le champ de frottement pariétal s'il n'existe pas encore
     (foamPostProcess -solver incompressibleFluid -func wallShearStress -latestTime) ;
  2. lit le dernier temps avec pyvista (patch « airfoil ») ;
  3. calcule Cp = p / (½ U²) et Cf = τ / (½ U²)   (p et τ sont « cinématiques »
     en incompressible, U = 1 m/s : donc Cp = 2 p et Cf = 2 τ) ;
     Cf est signé : positif si le frottement est dirigé du bord d'attaque vers le
     bord de fuite (écoulement attaché), négatif s'il remonte (écoulement décollé) ;
  4. repère sur l'extrados le point où Cf devient négatif : début du décollement ;
  5. compare Cp aux mesures de Gregory & O'Reilly (extrados, α = 0, 10, 15°).

Utilisation (depuis NACA0012/, environnement (foam) activé, OpenFOAM chargé) :
    python3 cp_cf_naca.py                         # angles 0 10 15 17 de polaire/
    python3 cp_cf_naca.py --angles 0 10 15 17 18  # autre liste
    python3 cp_cf_naca.py --dir polaire           # dossier contenant les cas aXX.X

Fichier de référence attendu à côté du script : CP_Gregory_expdata.dat
"""

import argparse
import glob
import os
import shutil
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def case_name(alpha):
    return "a%04.1f" % alpha


def latest_time(case):
    times = []
    for d in os.listdir(case):
        try:
            if float(d) > 0 and os.path.isdir(os.path.join(case, d)):
                times.append((float(d), d))
        except ValueError:
            pass
    return max(times)[1] if times else None


def ensure_wall_shear(case):
    t = latest_time(case)
    if t is None:
        return None
    if os.path.isfile(os.path.join(case, t, "wallShearStress")):
        return t
    if shutil.which("foamPostProcess") is None:
        print("  ! foamPostProcess introuvable : charge OpenFOAM pour calculer Cf")
        return t
    print("  calcul de wallShearStress au temps %s..." % t)
    with open(os.path.join(case, "log.wallShearStress"), "w") as fh:
        subprocess.run(["foamPostProcess", "-solver", "incompressibleFluid",
                        "-func", "wallShearStress", "-latestTime"],
                       cwd=case, stdout=fh, stderr=subprocess.STDOUT)
    return t


def read_airfoil(case, t):
    """Renvoie x, y, Cp, vecteur τ (ou None) sur les faces du profil."""
    import pyvista as pv
    foam = os.path.join(case, "case.foam")
    if not os.path.isfile(foam):
        open(foam, "w").close()
    r = pv.POpenFOAMReader(foam)
    r.set_active_time_value(float(t))
    names = r.patch_array_names
    target = [n for n in names if n in ("patch/airfoil", "airfoil")]
    if not target:
        raise RuntimeError("patch airfoil introuvable (patches : %s)" % names)
    r.disable_all_patch_arrays()
    r.enable_patch_array(target[0])
    r.cell_to_point_creation = False
    data = r.read()
    blk = data["boundary"]
    patch = blk["airfoil"]
    centers = patch.cell_centers().points
    p = np.asarray(patch.cell_data["p"])
    tau = None
    if "wallShearStress" in patch.cell_data.keys():
        tau = np.asarray(patch.cell_data["wallShearStress"])
    # le profil 2D a une épaisseur dz : on garde x, y
    return centers[:, 0], centers[:, 1], 2.0 * p, (None if tau is None else 2.0 * tau)


def surface(x, y, cp, tauv, upper):
    """Trie une surface du bord d'attaque au bord de fuite, Cf signé."""
    m = y >= 0 if upper else y < 0
    order = np.argsort(x[m])
    xs, ys, cps = x[m][order], y[m][order], cp[m][order]
    cf = None
    if tauv is not None:
        tv = tauv[m][order][:, :2]
        # tangente locale orientée bord d'attaque -> bord de fuite
        t = np.gradient(np.column_stack([xs, ys]), axis=0)
        t /= np.linalg.norm(t, axis=1)[:, None]
        cf = (tv * t).sum(axis=1)
    return xs, cps, cf


def separation_point(xs, cf):
    """Premier x/c (après le bord d'attaque) où Cf devient négatif, ou None."""
    if cf is None:
        return None
    ok = xs > 0.02
    neg = np.where(ok & (cf < 0))[0]
    return float(xs[neg[0]]) if len(neg) else None


def read_gregory(path):
    zones, cur = {}, None
    if not os.path.isfile(path):
        return zones
    for line in open(path):
        s = line.strip()
        if s.lower().startswith("zone"):
            cur = float(s.split("=")[-1].strip('"'))
            zones[cur] = []
        elif cur is not None and s and s[0] not in "#v":
            v = s.split()
            if len(v) >= 2:
                zones[cur].append([float(v[0]), float(v[1])])
    return {k: np.array(v) for k, v in zones.items()}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", default="polaire", help="dossier contenant les cas aXX.X")
    ap.add_argument("--angles", type=float, nargs="+", default=[0, 10, 15, 17])
    ap.add_argument("--out", default=None, help="figure (défaut : <dir>/cp_cf.png)")
    a = ap.parse_args()
    out = a.out or os.path.join(a.dir, "cp_cf.png")
    greg = read_gregory(os.path.join(HERE, "CP_Gregory_expdata.dat"))

    res = []
    for alpha in a.angles:
        case = os.path.join(a.dir, case_name(alpha))
        if not os.path.isdir(case):
            print("α = %g° : cas %s introuvable, ignoré" % (alpha, case))
            continue
        print("α = %g° (%s)" % (alpha, case))
        t = ensure_wall_shear(case)
        if t is None:
            print("  ! aucun temps de calcul écrit, ignoré")
            continue
        x, y, cp, tauv = read_airfoil(case, t)
        up = surface(x, y, cp, tauv, True)
        lo = surface(x, y, cp, tauv, False)
        if up[2] is not None:
            # Convention de signe : selon la version, OpenFOAM donne la contrainte
            # exercée par la paroi sur le fluide (opposée à l'écoulement) ou l'inverse.
            # On se cale sur la mi-corde, où l'écoulement est attaché des deux côtés :
            # Cf doit y être positif.
            mid = np.concatenate([up[2][(up[0] > 0.2) & (up[0] < 0.6)],
                                  lo[2][(lo[0] > 0.2) & (lo[0] < 0.6)]])
            if np.median(mid) < 0:
                up = (up[0], up[1], -up[2])
                lo = (lo[0], lo[1], -lo[2])
        xsep = separation_point(up[0], up[2])
        cpmin = cp.min()
        print("  Cp min = %.2f   décollement extrados : %s"
              % (cpmin, "x/c = %.3f" % xsep if xsep is not None else
                 ("aucun" if up[2] is not None else "Cf non disponible")))
        res.append(dict(alpha=alpha, up=up, lo=lo, xsep=xsep, cpmin=cpmin))

    if not res:
        sys.exit("Aucun cas lisible.")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9.5, "axes.grid": True, "grid.alpha": 0.3,
                         "axes.spines.top": False, "axes.spines.right": False})
    n = len(res)
    fig, axs = plt.subplots(2, n, figsize=(4.2 * n, 7.5), squeeze=False,
                            gridspec_kw=dict(height_ratios=[1.4, 1]))
    fig.suptitle("NACA 0012 — Re = 6×10⁶ — distributions de Cp et Cf (k-ω SST)",
                 fontsize=12, fontweight="bold")
    cu, cl_ = "#1f5fa8", "#c0392b"
    for j, r in enumerate(res):
        ax = axs[0, j]
        ax.plot(r["up"][0], r["up"][1], "-", color=cu, lw=1.4, label="extrados")
        ax.plot(r["lo"][0], r["lo"][1], "-", color=cl_, lw=1.4, label="intrados")
        g = greg.get(float(r["alpha"]))
        if g is not None:
            ax.plot(g[:, 0], g[:, 1], "o", ms=4, mfc="none", color="#555555",
                    label="Gregory & O'Reilly\n(extrados, Re = 2,9×10⁶)")
        ax.invert_yaxis()
        ax.set_title("α = %g°" % r["alpha"])
        ax.set_xlabel("x / c")
        if j == 0:
            ax.set_ylabel("$C_p$")
        ax.legend(fontsize=7.5, loc="best")

        ax = axs[1, j]
        if r["up"][2] is not None:
            ax.plot(r["up"][0], r["up"][2], "-", color=cu, lw=1.4, label="extrados")
            ax.plot(r["lo"][0], r["lo"][2], "-", color=cl_, lw=1.4, label="intrados")
            ax.axhline(0, color="k", lw=0.8)
            if r["xsep"] is not None:
                ax.axvline(r["xsep"], color=cu, ls="--", lw=1)
                ax.annotate("décollement\nx/c = %.2f" % r["xsep"], (r["xsep"], 0),
                            textcoords="offset points", xytext=(-70, 25), fontsize=8,
                            arrowprops=dict(arrowstyle="->", lw=0.8))
            ax.set_ylim(-0.003, 0.02)
            ax.legend(fontsize=7.5, loc="upper right")
        else:
            ax.text(0.5, 0.5, "Cf non disponible", ha="center", transform=ax.transAxes)
        ax.set_xlabel("x / c")
        if j == 0:
            ax.set_ylabel("$C_f$")
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(out, dpi=140)
    print("\nFigure : %s" % os.path.abspath(out))


if __name__ == "__main__":
    main()
