#!/usr/bin/env python3
r"""
post_naca.py — Post-traitement d'un calcul de profil sous OpenFOAM (Foundation 13/14).

Lit les sorties des function objects du controlDict :
    postProcessing/forceCoeffs/*/forceCoeffs*.dat
    postProcessing/residuals/*/residuals*.dat
    postProcessing/yPlus/*/yPlus*.dat

et produit :
    - une figure de convergence (Cl, Cd, Cm, résidus, y+) : postProcessing/convergence.png
    - un résumé dans le terminal : valeurs finales, stabilité, écart aux références

Exemples :
    python3 post_naca.py                              # dans le dossier du cas
    python3 post_naca.py --case ~/run/naca0012_re6e6
    python3 post_naca.py --label "NACA 0012, alpha = 4°"

Comparaison à Ladson (NASA TM 4074) : si le fichier CLCD_Ladson_expdata.dat est
trouvé (dossier du cas, data/ à côté, ou dossier du script), chaque série de
rugosité est interpolée à l'incidence du calcul, lue dans dragDir du controlDict.
Les valeurs saisies avec --ref-cl / --ref-cd sont prioritaires.

Les colonnes sont repérées par leur nom dans l'en-tête des fichiers : le script
s'adapte donc aux différences de format entre versions d'OpenFOAM.
"""

import argparse
import glob
import os
import sys

import numpy as np


# --------------------------------------------------------------------------
# Lecture des fichiers .dat d'OpenFOAM
# --------------------------------------------------------------------------
def read_dat(path):
    """Renvoie (noms de colonnes, liste de lignes découpées) d'un fichier .dat."""
    names, rows = None, []
    with open(path) as fh:
        for line in fh:
            s = line.strip()
            if not s:
                continue
            if s.startswith("#"):
                tokens = s.lstrip("#").split()
                if tokens and tokens[0].lower() == "time":
                    names = tokens
                continue
            rows.append(s.split())
    return names, rows


def to_float(x):
    try:
        return float(x)
    except ValueError:
        return np.nan


def load_function_object(case, name):
    """Concatène toutes les sorties d'un function object (gère les reprises)."""
    # la Foundation nomme parfois le dossier avec ses arguments, ex. residuals(p,U,k,omega)
    bases = sorted(glob.glob(os.path.join(case, "postProcessing", name)) +
                   glob.glob(os.path.join(case, "postProcessing", name + "(*")))
    dirs = []
    for base in bases:
        dirs += [d for d in glob.glob(os.path.join(base, "*")) if os.path.isdir(d)]
    dirs = sorted(dirs, key=lambda d: to_float(os.path.basename(d)))
    names, data = None, []
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, "*.dat"))):
            n, rows = read_dat(f)
            if n:
                names = n
            data.extend(rows)
    if not data or names is None:
        return None, None
    # en cas de reprise, une itération peut apparaître deux fois : on garde la dernière
    seen = {}
    for r in data:
        seen[to_float(r[0])] = r
    data = [seen[t] for t in sorted(seen)]
    return names, data


def column(names, rows, *candidates):
    """Extrait la première colonne dont le nom correspond (insensible à la casse)."""
    low = [n.lower() for n in names]
    for c in candidates:
        if c.lower() in low:
            k = low.index(c.lower())
            return np.array([to_float(r[k]) if k < len(r) else np.nan for r in rows])
    return None


# --------------------------------------------------------------------------
# Références expérimentales (Ladson, NASA TM 4074) et incidence du calcul
# --------------------------------------------------------------------------
LADSON_NAME = "CLCD_Ladson_expdata.dat"


def find_ladson(case, explicit):
    if explicit:
        return explicit if os.path.isfile(explicit) else None
    here = os.path.dirname(os.path.abspath(__file__))
    for d in [case, os.path.join(case, "data"), os.path.dirname(case),
              os.path.join(os.path.dirname(case), "data"), here,
              os.path.join(here, "data"), os.path.join(os.path.dirname(here), "data")]:
        p = os.path.join(d, LADSON_NAME)
        if os.path.isfile(p):
            return p
    return None


def read_ladson(path):
    """Renvoie {nom de série: tableau (alpha, cl, cd)}."""
    zones, cur = {}, None
    with open(path) as fh:
        for line in fh:
            s = line.strip()
            if s.lower().startswith("zone"):
                cur = s.split("=", 1)[-1].strip().strip('"')
                zones[cur] = []
            elif cur and s and not s.startswith("#") and not s.lower().startswith("variables"):
                vals = [to_float(x) for x in s.split()]
                if len(vals) >= 3 and all(np.isfinite(vals[:3])):
                    zones[cur].append(vals[:3])
    return {k: np.array(v) for k, v in zones.items() if v}


def ladson_at(zones, alpha):
    """Interpole chaque série à l'incidence alpha (partie avant décrochage)."""
    out = {}
    for name, d in zones.items():
        d = d[d[:, 2] < 0.05]          # on écarte les points décrochés
        d = d[np.argsort(d[:, 0])]
        if d[0, 0] <= alpha <= d[-1, 0]:
            out[name] = (np.interp(alpha, d[:, 0], d[:, 1]),
                         np.interp(alpha, d[:, 0], d[:, 2]))
    return out


def alpha_from_controldict(case):
    """Déduit l'incidence de dragDir dans system/controlDict."""
    import re
    try:
        txt = open(os.path.join(case, "system", "controlDict")).read()
    except OSError:
        return None
    m = re.search(r"dragDir\s*\(\s*([-\d.eE+]+)\s+([-\d.eE+]+)", txt)
    if not m:
        return None
    return float(np.degrees(np.arctan2(float(m.group(2)), float(m.group(1)))))


# --------------------------------------------------------------------------
# Analyse de convergence
# --------------------------------------------------------------------------
def stability(values, window, scale=None):
    """Moyenne et variation (max - min) sur la fenêtre finale, rapportée à `scale`
    (par défaut la moyenne elle-même). Pour Cm, proche de 0 sur un profil
    symétrique, on la rapporte à Cl : une variation relative à ~0 n'a pas de sens."""
    v = values[-window:]
    v = v[np.isfinite(v)]
    if len(v) == 0:
        return np.nan, np.nan
    mean = v.mean()
    ref = abs(scale) if scale is not None else abs(mean)
    spread = (v.max() - v.min()) / ref if ref != 0 else np.nan
    return mean, spread


def verdict(spread):
    if not np.isfinite(spread):
        return "?"
    if spread < 1e-4:
        return "convergé"
    if spread < 1e-3:
        return "presque"
    return "NON convergé"


# --------------------------------------------------------------------------
# Figure
# --------------------------------------------------------------------------
def make_figure(res, out, label):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.size": 10, "axes.grid": True, "grid.alpha": 0.3,
        "axes.spines.top": False, "axes.spines.right": False,
    })
    blue, red, green, grey = "#1f5fa8", "#c0392b", "#2e8b57", "#555555"

    fig, axs = plt.subplots(2, 2, figsize=(13, 9.5))
    fig.suptitle(label, fontsize=14, fontweight="bold")
    it = res["it"]
    win = res["window"]

    def coef_panel(ax, y, name, color, ref, band):
        ax.plot(it, y, color=color, lw=1.2)
        # zoom vertical sur la seconde moitié : on voit la stabilisation
        tail = y[len(y) // 2:]
        tail = tail[np.isfinite(tail)]
        if len(tail):
            lo, hi = tail.min(), tail.max()
            pad = max(hi - lo, 1e-3 * abs(tail.mean()), 1e-12)
            lims = [lo - 2 * pad, hi + 2 * pad]
            if ref is not None:
                lims = [min(lims[0], ref - pad), max(lims[1], ref + pad)]
            if band is not None:
                lims = [min(lims[0], band[0] - pad), max(lims[1], band[1] + pad)]
            ax.set_ylim(lims)
        ax.axvspan(it[-min(win, len(it))], it[-1], color=grey, alpha=0.08,
                   label="fenêtre d'analyse")
        if band is not None:
            ax.axhspan(band[0], band[1], color="#f0b429", alpha=0.25,
                       label="dispersion expérimentale")
        if ref is not None:
            ax.axhline(ref, color="k", ls="--", lw=1, label="référence")
        ax.set_xlabel("Itération")
        ax.set_ylabel(name)
        ax.legend(loc="best", fontsize=8)

    coef_panel(axs[0, 0], res["Cl"], "$C_l$", blue, res["ref_cl"], res["band_cl"])
    axs[0, 0].set_title("Portance")
    coef_panel(axs[0, 1], res["Cd"], "$C_d$", red, res["ref_cd"], res["band_cd"])
    axs[0, 1].set_title("Traînée")

    ax = axs[1, 0]
    if res["residuals"]:
        for name, (rit, rv) in res["residuals"].items():
            ok = np.isfinite(rv) & (rv > 0)
            if ok.any():
                ax.semilogy(rit[ok], rv[ok], lw=1, label=name)
        ax.legend(loc="upper right", fontsize=8, ncol=2)
    else:
        ax.text(0.5, 0.5, "pas de fichier residuals", ha="center", transform=ax.transAxes)
    ax.set_title("Résidus initiaux")
    ax.set_xlabel("Itération")

    ax = axs[1, 1]
    ax.axis("off")
    ax.text(0.0, 1.0, res["summary"], va="top", ha="left", family="monospace",
            fontsize=8.5, transform=ax.transAxes)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out, dpi=140)
    return out


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--case", default=".", help="dossier du cas (défaut : dossier courant)")
    ap.add_argument("--window", type=int, default=500,
                    help="nombre d'itérations finales pour juger la convergence")
    ap.add_argument("--ref-cl", type=float, help="Cl de référence (expérience)")
    ap.add_argument("--ref-cd", type=float, help="Cd de référence (expérience)")
    ap.add_argument("--label", default=None, help="titre de la figure")
    ap.add_argument("--ladson", default=None,
                    help="fichier %s (par défaut : cherché automatiquement)" % LADSON_NAME)
    ap.add_argument("--alpha", type=float, default=None,
                    help="incidence en degrés (par défaut : lue dans dragDir du controlDict)")
    ap.add_argument("--no-ladson", action="store_true", help="ne pas comparer à Ladson")
    a = ap.parse_args()

    case = os.path.abspath(os.path.expanduser(a.case))
    names, rows = load_function_object(case, "forceCoeffs")
    if names is None:
        sys.exit("Aucun fichier forceCoeffs trouvé dans %s/postProcessing" % case)

    it = column(names, rows, "Time")
    cl = column(names, rows, "Cl")
    cd = column(names, rows, "Cd")
    cm = column(names, rows, "CmPitch", "Cm")
    if cl is None or cd is None:
        sys.exit("Colonnes Cl / Cd introuvables. En-tête lu : %s" % " ".join(names))

    win = min(a.window, len(it))
    # Cl et Cm peuvent valoir ~0 (profil symétrique à 0°) : une variation relative
    # à ~0 n'a pas de sens. On les rapporte à une échelle de portance d'au moins 0,1.
    lift_scale = max(abs(np.nanmean(cl[-win:])), 0.1)
    cl_m, cl_s = stability(cl, win, scale=lift_scale)
    cd_m, cd_s = stability(cd, win)
    cm_m, cm_s = stability(cm, win, scale=lift_scale) if cm is not None else (np.nan, np.nan)

    # références Ladson
    band_cl = band_cd = None
    ladson_lines = []
    alpha = a.alpha if a.alpha is not None else alpha_from_controldict(case)
    lpath = None if a.no_ladson else find_ladson(case, a.ladson)
    if lpath and alpha is not None:
        pts = ladson_at(read_ladson(lpath), alpha)
        if pts:
            cls = np.array([v[0] for v in pts.values()])
            cds = np.array([v[1] for v in pts.values()])
            band_cl, band_cd = (cls.min(), cls.max()), (cds.min(), cds.max())
            if a.ref_cl is None:
                a.ref_cl = cls.mean()
            if a.ref_cd is None:
                a.ref_cd = cds.mean()
            ladson_lines.append("Ladson (déclenché), interpolé à alpha = %.2f° :" % alpha)
            for n, (c1, c2) in pts.items():
                ladson_lines.append("  %-9s Cl %.4f   Cd %.5f" % (n, c1, c2))
    elif not a.no_ladson:
        if lpath is None:
            ladson_lines.append("Ladson : fichier %s introuvable (--ladson)" % LADSON_NAME)
        else:
            ladson_lines.append("Ladson : incidence inconnue (--alpha)")

    # résidus
    residuals = {}
    rn, rr = load_function_object(case, "residuals")
    if rn is not None:
        rit = column(rn, rr, "Time")
        for k, n in enumerate(rn[1:], start=1):
            v = np.array([to_float(r[k]) if k < len(r) else np.nan for r in rr])
            if np.isfinite(v).any():
                residuals[n] = (rit, v)
    res_last = {n: v[np.isfinite(v)][-1] for n, (_, v) in residuals.items()
                if np.isfinite(v).any()}

    # y+
    yp_line = "y+ : pas de fichier yPlus"
    yn, yr = load_function_object(case, "yPlus")
    if yn is not None:
        rows_af = [r for r in yr if len(r) > 1 and r[1] == "airfoil"] or yr
        last = rows_af[-1]
        vals = [to_float(x) for x in last[2:5]]
        if len(vals) == 3:
            yp_line = "y+ paroi (it. %s) : min %.3g  max %.3g  moy %.3g" % (last[0], *vals)

    # résumé
    lines = []
    lines.append("Itérations : %d   (fenêtre d'analyse : %d dernières)" % (it[-1], win))
    lines.append("")
    lines.append("%-4s %11s %13s   %s" % ("", "valeur", "variation", "état"))
    for nm, m, s in [("Cl", cl_m, cl_s), ("Cd", cd_m, cd_s), ("Cm", cm_m, cm_s)]:
        if np.isfinite(m):
            lines.append("%-4s %11.5f %12.1e   %s" % (nm, m, s, verdict(s)))
    lines.append("     (variations de Cl et Cm rapportées à max(|Cl|, 0,1))")
    if np.isfinite(cl_m) and np.isfinite(cd_m) and cd_m != 0:
        lines.append("")
        lines.append("Finesse Cl/Cd : %.1f" % (cl_m / cd_m))
    if ladson_lines:
        lines.append("")
        lines.extend(ladson_lines)

    def inband(v, b):
        if b is None:
            return ""
        return "  (dans la dispersion)" if b[0] <= v <= b[1] else "  (hors dispersion)"

    if a.ref_cl is not None or a.ref_cd is not None:
        lines.append("")
        lines.append("Écart à la référence (moyenne) :")
        if a.ref_cl is not None:
            if abs(a.ref_cl) < 0.05:   # portance quasi nulle : écart absolu, pas en %
                lines.append("  Cl : %.4f vs %.4f  ->  écart %+.4f%s" % (
                    cl_m, a.ref_cl, cl_m - a.ref_cl, inband(cl_m, band_cl)))
            else:
                lines.append("  Cl : %.4f vs %.4f  ->  %+.1f %%%s" % (
                    cl_m, a.ref_cl, 100 * (cl_m - a.ref_cl) / a.ref_cl, inband(cl_m, band_cl)))
        if a.ref_cd is not None:
            lines.append("  Cd : %.5f vs %.5f  ->  %+.1f %%%s" % (
                cd_m, a.ref_cd, 100 * (cd_m - a.ref_cd) / a.ref_cd, inband(cd_m, band_cd)))
    lines.append("")
    lines.append(yp_line)
    if res_last:
        lines.append("")
        lines.append("Derniers résidus :")
        for n, v in res_last.items():
            lines.append("  %-8s %.2e" % (n, v))
    summary = "\n".join(lines)

    print("\n" + summary + "\n")
    label = a.label or os.path.basename(case)
    out = make_figure(dict(it=it, Cl=cl, Cd=cd, window=win, residuals=residuals,
                           ref_cl=a.ref_cl, ref_cd=a.ref_cd, band_cl=band_cl,
                           band_cd=band_cd, summary=summary),
                      os.path.join(case, "postProcessing", "convergence.png"), label)
    print("Figure : %s" % out)


if __name__ == "__main__":
    main()
