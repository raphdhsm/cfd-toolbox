# NACA 0012 à Re = 6×10⁶ — validation OpenFOAM k-ω SST

Validation d'une chaîne de calcul OpenFOAM 13 (RANS stationnaire, k-ω SST, couche
limite résolue à y⁺ ≈ 0,5) sur le cas de référence NACA 0012 du NASA Turbulence
Modeling Resource, contre les essais de Ladson (NASA TM-4074, 1988).

**Résultat :** de 0 à 12° d'incidence, la portance est à environ 1 % de l'expérience
et la traînée à quelques pourcents, dans la dispersion des mesures. Au-delà, le modèle
surestime la traînée de 10 à 15 % et ne capte pas le décrochage brutal du bord d'attaque.

![Polaire](figures/polaire.png)

## Ce qui a été fait

| Étape | Résultat |
| --- | --- |
| Maillage en C maison (script Python) | lignes normales à la paroi (2,6° d'écart moyen), 1re maille 4,61×10⁻⁶ m, y⁺ calculé 0,54 (max 1,05) |
| Étude de maillage à 4° (GCI, 3 maillages ×2) | Cl : ±0,7 % (ordre observé 1,22) ; Cd : ±1,8 % (maillage grossier écarté, y⁺ ≈ 1–2) |
| Taille du domaine (25, 50, 100 cordes) | erreur en 1/R, surtout sur Cd : +3,4 % à 50 cordes à 4° → polaire à 200 cordes |
| Validation à 4° (corrigée maillage + domaine) | Cl 0,4347 (+1,5 % ; −0,6 % hors décalage de zéro de Ladson), Cd 0,00848 (+1,2 %) |
| Validation à 0° contre les codes NASA | Cd ≈ 0,0081, comme CFL3D / FUN3D / NTS (0,00808–0,00809) |
| Polaire 0–19° (17 angles) | validée jusqu'à 12° ; Cd +10 à +15 % entre 13 et 17° ; décrochage non capté |
| Cp et Cf | Cp sur Gregory & O'Reilly à 0, 10, 15° ; décollement au bord de fuite (x/c = 0,99 à 15°, 0,87 à 17°) |

Rapport complet : [Validation NACA 0012 — OpenFOAM k-ω SST](https://claude.ai/code/artifact/e2047902-9640-4ca4-922a-1313965d4496) (export PDF à déposer dans `rapport/`).

## Pièges rencontrés

- **Turbulence ambiante qui décroît + frontières `inletOutlet`** : sauts du résidu de ω,
  traînée bruitée. Corrigé par des termes de maintien (`constant/fvModels`,
  Spalart & Rumsey 2007) et k, ω imposés sur le champ lointain.
- **Domaine trop petit** : la portance se projette sur la traînée (ΔCd ≈ Cl × Δα),
  erreur proportionnelle à Cl.
- **Maillage grossier qui « colle » à l'expérience** par compensation d'erreurs.
- **Turbulence d'entrée de la NASA (νt/ν = 0,009)** : écoulement instationnaire avec
  OpenFOAM ; les valeurs génériques k∞ = 10⁻⁶ U², ω∞ = 5 U/c donnent un écoulement
  tout turbulent.
- **Convergence** : jugée sur Cl et Cd ; 8 000 itérations (maillage moyen) à 20 000 (fin).

## Contenu

```
naca0012/
├── README.md
├── cas_base/                 cas OpenFOAM à 4° (entrées seulement) + Allrun / Allclean
├── naca_cmesh.py             maillage en C paramétré (--level pour l'étude de maillage)
├── post_naca.py              convergence d'un cas + comparaison automatique à Ladson
├── gci_naca.py               étude de maillage (GCI, Celik et al. 2008)
├── domaine_naca.py           sensibilité à la taille du domaine
├── polaire_naca.py           polaire automatisée (foamlib)
├── cp_cf_naca.py             Cp, Cf et point de décollement (pyvista)
├── CLCD_Ladson_expdata.dat   essais de Ladson (NASA TMR)
├── CP_Gregory_expdata.dat    Cp de Gregory & O'Reilly (NASA TMR)
└── figures/
```

## Reproduire

OpenFOAM 13 (openfoam.org) chargé, environnement Python avec numpy, scipy, matplotlib,
foamlib et pyvista.

```bash
# 1. Un point à 4° (maillage moyen, domaine 50 cordes)
cd cas_base && ./Allrun && cd ..

# 2. Étude de maillage : copier cas_base, ajouter --level -1 ou --level 1 dans Allrun, puis
python3 gci_naca.py cas_grossier cas_base cas_fin

# 3. Polaire complète (domaine 200 cordes, 2 calculs en parallèle)
python3 polaire_naca.py --base cas_base

# 4. Cp et Cf
python3 cp_cf_naca.py
```

## Sources

- C. L. Ladson, NASA TM-4074, 1988 — https://ntrs.nasa.gov/citations/19880019495
- NASA Turbulence Modeling Resource, 2D NACA 0012 Airfoil Validation — https://tmbwg.github.io/turbmodels/naca0012_val.html
- Résultats SST des codes NASA (compilés par Flow360) — https://docs.flexcompute.com/projects/flow360/en/latest/caseStudies/NACA0012/NACA0012.html
- I. B. Celik et al., ASME J. Fluids Eng. 130, 2008 (GCI)
- P. R. Spalart et C. L. Rumsey, AIAA Journal 45(10), 2007 (maintien de la turbulence ambiante)
