#!/usr/bin/env python3
r"""
polaire_naca.py — Calcul automatique d'une polaire (Cl, Cd en fonction de alpha)
avec OpenFOAM, piloté par foamlib.

Ce que fait le script :
  1. génère UNE fois le maillage (naca_cmesh.py) avec le domaine choisi ;
  2. crée un cas par incidence à partir d'un cas de base (0/, constant/, system/),
     et règle avec foamlib : la vitesse Uinf (0/U), les directions dragDir et
     liftDir de forceCoeffs, et endTime ;
  3. lance les calculs (foamRun) plusieurs à la fois ;
  4. dépouille : valeur convergée de Cl et Cd pour chaque angle, tableau CSV,
     figure de la polaire comparée à Ladson et aux calculs SST de la NASA.

Le script est REPRENABLE : un cas déjà terminé (« End » dans log.foamRun) n'est
pas relancé ; un cas interrompu repart de son dernier temps écrit
(startFrom latestTime). Tu peux donc l'arrêter (Ctrl+C) et le relancer.

Utilisation (depuis NACA0012/, environnement (foam) activé, OpenFOAM chargé) :
    python3 polaire_naca.py                    # tout : maillage, cas, calculs, figure
    python3 polaire_naca.py --njobs 3          # 3 calculs en parallèle
    python3 polaire_naca.py --post-only        # seulement le dépouillement
    python3 polaire_naca.py --angles 0 4 10    # autre liste d'angles

Fichiers attendus dans le même dossier que ce script :
    naca_cmesh.py, post_naca.py, gci_naca.py, CLCD_Ladson_expdata.dat
"""

import argparse
import csv
import math
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import post_naca as pn  # noqa: E402
from gci_naca import converged_value  # noqa: E402

ANGLES = [0, 2, 4, 6, 8, 10, 11, 12, 13, 14, 15, 16, 16.5, 17, 17.5, 18, 19]

# Calculs de référence NASA (CFL3D, SST, maillage 897x257, frontière à ~500 cordes)
NASA_SST = [(0.0, 0.0, 0.00809), (10.0, 1.0778, 0.01236), (15.0, 1.5068, 0.02219)]


def case_name(alpha):
    return "a%04.1f" % alpha          # a00.0, a04.0, a16.5 ...


def log(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


# --------------------------------------------------------------------------
# 1. Maillage (une seule fois)
# --------------------------------------------------------------------------
def make_mesh(a, mesh_dir):
    if os.path.isfile(os.path.join(mesh_dir, "constant", "polyMesh", "points")):
        log("Maillage déjà présent : %s" % mesh_dir)
        return
    log("Génération du maillage (domaine %g cordes)..." % a.farfield)
    os.makedirs(mesh_dir, exist_ok=True)
    cmd = [sys.executable, os.path.join(HERE, "naca_cmesh.py"), "--naca", "0012",
           "--re", str(a.re), "--farfield", str(a.farfield),
           "--wake-length", str(a.farfield), "--out", mesh_dir]
    with open(os.path.join(mesh_dir, "log.naca_cmesh"), "w") as fh:
        subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, check=True)
    # checkMesh a besoin d'un system/ : on prend celui du cas de base
    shutil.copytree(os.path.join(a.base, "system"), os.path.join(mesh_dir, "system"),
                    dirs_exist_ok=True)
    with open(os.path.join(mesh_dir, "log.checkMesh"), "w") as fh:
        subprocess.run(["checkMesh"], cwd=mesh_dir, stdout=fh, stderr=subprocess.STDOUT)
    log("Maillage prêt (voir %s/log.checkMesh)" % mesh_dir)


# --------------------------------------------------------------------------
# 2. Création d'un cas par angle (foamlib)
# --------------------------------------------------------------------------
def make_case(a, alpha, mesh_dir):
    from foamlib import FoamFile

    case = os.path.join(a.out, case_name(alpha))
    if os.path.isdir(case):
        return case
    os.makedirs(case)
    shutil.copytree(os.path.join(a.base, "0"), os.path.join(case, "0"))
    shutil.copytree(os.path.join(a.base, "system"), os.path.join(case, "system"))
    shutil.copytree(os.path.join(a.base, "constant"), os.path.join(case, "constant"),
                    ignore=shutil.ignore_patterns("polyMesh"))
    shutil.copytree(os.path.join(mesh_dir, "constant", "polyMesh"),
                    os.path.join(case, "constant", "polyMesh"))

    r = math.radians(alpha)
    ca, sa = round(math.cos(r), 6), round(math.sin(r), 6)
    FoamFile(os.path.join(case, "0", "U"))["Uinf"] = [ca, sa, 0]
    # met à jour le commentaire « alpha = ... » pour qu'il ne mente pas
    up = os.path.join(case, "0", "U")
    txt = open(up).read()
    txt = re.sub(r"alpha\s*=\s*[-\d.]+\s*(deg|°)", "alpha = %g deg" % alpha, txt)
    open(up, "w").write(txt)
    cd = FoamFile(os.path.join(case, "system", "controlDict"))
    cd["endTime"] = a.endtime
    cd["functions"]["forceCoeffs"]["dragDir"] = [ca, sa, 0]
    cd["functions"]["forceCoeffs"]["liftDir"] = [-sa, ca, 0]
    return case


def is_finished(case):
    p = os.path.join(case, "log.foamRun")
    if not os.path.isfile(p):
        return False
    with open(p, "rb") as fh:
        fh.seek(0, 2)
        fh.seek(max(0, fh.tell() - 4000))
        tail = fh.read().decode(errors="ignore")
    return "\nEnd" in tail


# --------------------------------------------------------------------------
# 3. Lancement
# --------------------------------------------------------------------------
def run_case(case):
    name = os.path.basename(case)
    if is_finished(case):
        log("%s : déjà terminé, ignoré" % name)
        return name, 0
    log("%s : lancement de foamRun" % name)
    t0 = time.time()
    with open(os.path.join(case, "log.foamRun"), "a") as fh:
        ret = subprocess.run(["foamRun"], cwd=case, stdout=fh, stderr=subprocess.STDOUT).returncode
    log("%s : %s en %.0f min" % (name, "terminé" if ret == 0 else "ERREUR (voir log.foamRun)",
                                 (time.time() - t0) / 60))
    return name, ret


# --------------------------------------------------------------------------
# 4. Dépouillement
# --------------------------------------------------------------------------
def postprocess(a, angles):
    rows = []
    for alpha in angles:
        case = os.path.join(a.out, case_name(alpha))
        hdr, data = (None, None)
        if os.path.isdir(case):
            hdr, data = pn.load_function_object(case, "forceCoeffs")
        if hdr is None:
            rows.append(dict(alpha=alpha, etat="pas de résultat"))
            continue
        it = pn.column(hdr, data, "Time")
        cl_hist, cd_hist = pn.column(hdr, data, "Cl"), pn.column(hdr, data, "Cd")
        cl, _, _ = converged_value(it, cl_hist, a.block)
        cd, _, _ = converged_value(it, cd_hist, a.block)
        # oscillations résiduelles sur la fin du calcul (bruit relatif de Cl)
        tail = cl_hist[-min(2000, len(cl_hist)):]
        osc = (np.percentile(tail, 95) - np.percentile(tail, 5)) / max(abs(cl), 0.1)
        if not is_finished(case):
            etat = "en cours"
        elif osc > 0.01:
            etat = "oscillant"
        else:
            etat = "convergé"
        rows.append(dict(alpha=alpha, cl=cl, cd=cd, finesse=cl / cd, iterations=int(it[-1]),
                         oscillation=osc, etat=etat))

    # tableau
    print("\n alpha      Cl        Cd      Cl/Cd   itér.  oscill.  état")
    for r in rows:
        if "cl" in r:
            print("%6.1f  %8.4f  %8.5f  %6.1f  %6d  %6.1f %%  %s"
                  % (r["alpha"], r["cl"], r["cd"], r["finesse"], r["iterations"],
                     100 * r["oscillation"], r["etat"]))
        else:
            print("%6.1f  %s" % (r["alpha"], r["etat"]))
    csv_path = os.path.join(a.out, "polaire.csv")
    with open(csv_path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["alpha", "cl", "cd", "finesse", "iterations",
                                           "oscillation", "etat"])
        w.writeheader()
        w.writerows(rows)

    # figure
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.grid": True, "grid.alpha": 0.3,
                         "axes.spines.top": False, "axes.spines.right": False})
    ok = [r for r in rows if "cl" in r]
    al = np.array([r["alpha"] for r in ok])
    cl = np.array([r["cl"] for r in ok])
    cd = np.array([r["cd"] for r in ok])
    good = np.array([r["etat"] == "convergé" for r in ok])

    lad = {}
    lp = os.path.join(HERE, pn.LADSON_NAME)
    if os.path.isfile(lp):
        lad = pn.read_ladson(lp)
    nasa = np.array(NASA_SST)

    fig, axs = plt.subplots(2, 2, figsize=(13, 9.5))
    fig.suptitle("Polaire NACA 0012 — Re = 6×10⁶ — k-ω SST (OpenFOAM), domaine %g cordes"
                 % a.farfield, fontsize=13, fontweight="bold")
    blue = "#1f5fa8"

    def series(ax, x, y, xl, yl, title, xr=None, yr=None):
        for (name, d), m in zip(lad.items(), ["o", "^", "s"]):
            d = d[np.argsort(d[:, 0])]
            ax.plot(xr(d) if xr else d[:, 0], yr(d) if yr else d[:, 1], m, ms=4,
                    mfc="none", color="#9a9a9a", label="Ladson %s" % name)
        ax.plot(x, y, "-", color=blue, lw=1.5)
        ax.plot(x[good], y[good], "o", color=blue, ms=6, label="OpenFOAM (convergé)")
        if (~good).any():
            ax.plot(x[~good], y[~good], "o", mfc="white", color=blue, ms=6,
                    label="OpenFOAM (oscillant / en cours)")
        ax.set_xlabel(xl)
        ax.set_ylabel(yl)
        ax.set_title(title)

    series(axs[0, 0], al, cl, "α (°)", "$C_l$", "Portance",
           yr=lambda d: d[:, 1])
    axs[0, 0].plot(nasa[:, 0], nasa[:, 1], "D", color="k", ms=6, label="CFL3D SST (NASA)")
    series(axs[0, 1], al, cd, "α (°)", "$C_d$", "Traînée", yr=lambda d: d[:, 2])
    axs[0, 1].plot(nasa[:, 0], nasa[:, 2], "D", color="k", ms=6, label="CFL3D SST (NASA)")
    series(axs[1, 0], cd, cl, "$C_d$", "$C_l$", "Polaire de traînée",
           xr=lambda d: d[:, 2], yr=lambda d: d[:, 1])
    axs[1, 0].plot(nasa[:, 2], nasa[:, 1], "D", color="k", ms=6, label="CFL3D SST (NASA)")
    series(axs[1, 1], al, cl / cd, "α (°)", "$C_l / C_d$", "Finesse",
           yr=lambda d: d[:, 1] / d[:, 2])
    for ax in axs.ravel():
        ax.legend(fontsize=7.5, loc="best")
    for ax in (axs[0, 0], axs[0, 1], axs[1, 1]):
        ax.set_xlim(-0.5, max(20, al.max() + 1) if len(al) else 20)
    axs[1, 1].set_ylim(bottom=0)
    axs[1, 0].set_ylim(bottom=-0.05)
    axs[0, 1].set_ylim(0, max(0.035, np.nanmax(cd) * 1.1) if len(cd) else 0.035)
    axs[1, 0].set_xlim(0, max(0.035, np.nanmax(cd) * 1.1) if len(cd) else 0.035)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig_path = os.path.join(a.out, "polaire.png")
    fig.savefig(fig_path, dpi=140)
    print("\nTableau : %s\nFigure  : %s\n" % (csv_path, fig_path))


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default="naca0012_re6e6",
                    help="cas de base (0/, constant/, system/) — défaut : naca0012_re6e6")
    ap.add_argument("--out", default="polaire", help="dossier qui recevra tous les cas")
    ap.add_argument("--angles", type=float, nargs="+", default=ANGLES, help="incidences (°)")
    ap.add_argument("--farfield", type=float, default=200, help="taille du domaine (cordes)")
    ap.add_argument("--re", type=float, default=6e6, help="Reynolds")
    ap.add_argument("--endtime", type=int, default=15000, help="itérations maximum par cas")
    ap.add_argument("--njobs", type=int, default=2, help="calculs lancés en parallèle")
    ap.add_argument("--block", type=int, default=2000,
                    help="taille des blocs d'itérations pour juger la convergence")
    ap.add_argument("--post-only", action="store_true", help="seulement le dépouillement")
    a = ap.parse_args()
    a.base = os.path.abspath(a.base)
    a.out = os.path.abspath(a.out)
    angles = sorted(a.angles)

    if not a.post_only:
        if shutil.which("foamRun") is None:
            sys.exit("foamRun introuvable : charge OpenFOAM dans ce terminal avant de lancer.")
        for sub in ["0", "constant", "system"]:
            if not os.path.isdir(os.path.join(a.base, sub)):
                sys.exit("Cas de base incomplet : %s/%s manquant" % (a.base, sub))
        mesh_dir = os.path.join(a.out, "_maillage")
        make_mesh(a, mesh_dir)
        cases = [make_case(a, alpha, mesh_dir) for alpha in angles]
        log("%d cas prêts dans %s, %d calculs à la fois" % (len(cases), a.out, a.njobs))
        try:
            with ThreadPoolExecutor(max_workers=a.njobs) as pool:
                results = list(pool.map(run_case, cases))
        except KeyboardInterrupt:
            log("Interrompu. Relance la même commande pour reprendre là où tu t'es arrêté.")
            raise
        bad = [n for n, ret in results if ret != 0]
        if bad:
            log("Calculs en erreur : %s" % ", ".join(bad))

    postprocess(a, angles)


if __name__ == "__main__":
    main()
