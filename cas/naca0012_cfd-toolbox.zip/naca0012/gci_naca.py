#!/usr/bin/env python3
r"""
gci_naca.py — Étude de convergence en maillage (méthode GCI, Celik et al. 2008,
ASME J. Fluids Eng.) sur trois calculs OpenFOAM du même cas.

Pour chaque maillage, le script :
  1. lit l'historique de Cl et Cd (postProcessing/forceCoeffs) ;
  2. estime la valeur convergée en itérations :
       - si le coefficient dérive encore de façon régulière (cas du maillage fin),
         il extrapole la dérive (méthode d'Aitken sur trois blocs successifs) ;
       - s'il oscille ou s'il est stable, il prend la médiane de la fin du calcul ;
  3. compte les cellules (constant/polyMesh/owner).

Puis, avec les trois valeurs :
  - ordre de convergence observé p ;
  - valeur extrapolée « à maillage infini » (Richardson) ;
  - incertitude numérique du maillage fin et du maillage moyen (GCI) ;
  - figure Cl et Cd en fonction de la taille de maille, avec la bande de Ladson.

Utilisation (depuis le dossier qui contient les trois cas) :
    python3 gci_naca.py naca0012_grossier naca0012_re6e6 naca0012_fin

Ordre des arguments : du plus GROSSIER au plus FIN.
Ce script importe post_naca.py : les deux fichiers doivent être dans le même dossier.
"""

import argparse
import math
import os
import re
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import post_naca as pn  # noqa: E402


# --------------------------------------------------------------------------
# Valeur convergée en itérations
# --------------------------------------------------------------------------
def converged_value(it, y, block):
    """Renvoie (valeur, méthode, incertitude itérative estimée)."""
    ok = np.isfinite(y)
    it, y = it[ok], y[ok]
    n = len(y)
    block = min(block, n // 4)
    if block < 50:
        return np.median(y[-max(n // 4, 1):]), "médiane (historique court)", np.nan

    # médianes de trois blocs successifs en fin de calcul (robustes aux pics isolés)
    b1 = np.median(y[n - 3 * block:n - 2 * block])
    b2 = np.median(y[n - 2 * block:n - block])
    b3 = np.median(y[n - block:])
    d1, d2 = b2 - b1, b3 - b2
    tail = y[-2 * block:]
    noise = np.percentile(tail, 90) - np.percentile(tail, 10)

    # dérive régulière qui ralentit : même signe, |d2| < |d1|, et nettement
    # au-dessus du bruit -> on extrapole (Aitken)
    if d1 * d2 > 0 and abs(d2) < abs(d1) and abs(d2) > 0.5 * noise:
        x_inf = b3 - d2 ** 2 / (d2 - d1)
        return x_inf, "extrapolée (dérive)", abs(x_inf - y[-1])

    return np.median(tail), "médiane (stable/oscillant)", noise / 2


def n_cells(case):
    path = os.path.join(case, "constant", "polyMesh", "owner")
    try:
        with open(path) as fh:
            head = fh.read(2000)
        m = re.search(r"nCells:\s*(\d+)", head)
        if m:
            return int(m.group(1))
    except OSError:
        pass
    log = os.path.join(case, "log.checkMesh")
    if os.path.isfile(log):
        m = re.search(r"cells:\s+(\d+)", open(log).read())
        if m:
            return int(m.group(1))
    return None


# --------------------------------------------------------------------------
# GCI (Celik et al. 2008)
# --------------------------------------------------------------------------
def gci(phi3, phi2, phi1, h3, h2, h1, p_formal=2.0):
    """phi3 grossier, phi2 moyen, phi1 fin (et tailles de maille h associées)."""
    r21, r32 = h2 / h1, h3 / h2
    e32, e21 = phi3 - phi2, phi2 - phi1
    out = dict(r21=r21, r32=r32, e21=e21, e32=e32)
    if e21 == 0 or e32 == 0:
        out.update(p=np.nan, monotone=False)
        return out
    s = np.sign(e32 / e21)
    out["monotone"] = s > 0

    # résolution de l'ordre observé (point fixe)
    p = abs(math.log(abs(e32 / e21))) / math.log(r21)
    for _ in range(200):
        q = math.log((r21 ** p - s) / (r32 ** p - s)) if (r32 ** p - s) > 0 and (r21 ** p - s) > 0 else 0.0
        p_new = abs(math.log(abs(e32 / e21)) + q) / math.log(r21)
        if abs(p_new - p) < 1e-10:
            break
        p = p_new
    out["p"] = p

    # facteur de sécurité : 1,25 si l'ordre observé est proche de l'ordre formel,
    # sinon 3 avec un ordre borné (recommandation de Roache)
    if abs(p - p_formal) <= 0.5:
        fs, p_use = 1.25, p
    else:
        fs, p_use = 3.0, min(max(p, 0.5), p_formal)
    out.update(fs=fs, p_use=p_use)

    out["phi_ext"] = (r21 ** p_use * phi1 - phi2) / (r21 ** p_use - 1)
    ea21 = abs((phi1 - phi2) / phi1)
    ea32 = abs((phi2 - phi3) / phi2)
    out["gci_fine"] = fs * ea21 / (r21 ** p_use - 1)
    out["gci_medium"] = fs * ea32 / (r32 ** p_use - 1)
    # rapport d'asymptoticité : proche de 1 si on est dans le domaine asymptotique
    out["asym"] = out["gci_medium"] / (r21 ** p_use * out["gci_fine"]) if out["gci_fine"] else np.nan
    return out


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cases", nargs=3, help="dossiers des cas : grossier moyen fin")
    ap.add_argument("--block", type=int, default=3000,
                    help="taille des blocs d'itérations pour juger la dérive (défaut 3000)")
    ap.add_argument("--out", default="convergence_maillage.png", help="figure de sortie")
    ap.add_argument("--label", default="Étude de convergence en maillage", help="titre")
    a = ap.parse_args()

    cases = [os.path.abspath(os.path.expanduser(c)) for c in a.cases]
    names = ["grossier", "moyen", "fin"]
    data = {"Cl": [], "Cd": []}
    cells = []

    print("\n=== Valeurs convergées en itérations ===\n")
    for nm, case in zip(names, cases):
        hdr, rows = pn.load_function_object(case, "forceCoeffs")
        if hdr is None:
            sys.exit("Pas de forceCoeffs dans %s" % case)
        it = pn.column(hdr, rows, "Time")
        nc = n_cells(case)
        if nc is None:
            sys.exit("Nombre de cellules introuvable pour %s" % case)
        cells.append(nc)
        print("%-9s %8d cellules, %6d itérations" % (nm, nc, it[-1]))
        for coef in ["Cl", "Cd"]:
            y = pn.column(hdr, rows, coef)
            v, how, unc = converged_value(it, y, a.block)
            data[coef].append(v)
            print("   %s = %.5f   [%s, incertitude itérative ~ %.1e]" % (coef, v, how, unc))
    print()

    # taille de maille représentative en 2D : h = (1/N)^(1/2), normalisée par le fin
    h = np.array([(1.0 / n) ** 0.5 for n in cells])
    hn = h / h[2]

    # références Ladson
    alpha = pn.alpha_from_controldict(cases[1])
    lpath = pn.find_ladson(cases[1], None)
    ref = {}
    if lpath and alpha is not None:
        pts = pn.ladson_at(pn.read_ladson(lpath), alpha)
        if pts:
            cls = np.array([v[0] for v in pts.values()])
            cds = np.array([v[1] for v in pts.values()])
            ref = {"Cl": (cls.min(), cls.mean(), cls.max()),
                   "Cd": (cds.min(), cds.mean(), cds.max())}

    results = {}
    print("=== Analyse GCI (Celik et al. 2008) ===\n")
    print("Rapports de raffinement : r21 = %.3f, r32 = %.3f\n" % (h[1] / h[2], h[0] / h[1]))
    for coef in ["Cl", "Cd"]:
        phi3, phi2, phi1 = data[coef]
        g = gci(phi3, phi2, phi1, h[0], h[1], h[2])
        results[coef] = g
        print("%s : grossier %.5f | moyen %.5f | fin %.5f" % (coef, phi3, phi2, phi1))
        if not np.isfinite(g.get("p", np.nan)):
            print("   écarts nuls : analyse impossible\n")
            continue
        print("   convergence %s" % ("monotone" if g["monotone"] else
                                     "OSCILLANTE (écarts de signes opposés)"))
        print("   ordre observé p = %.2f   (ordre formel du schéma : 2)" % g["p"])
        if g["fs"] > 1.25:
            print("   -> p éloigné de 2 : on n'est probablement pas dans le domaine "
                  "asymptotique ;\n      GCI calculé prudemment (Fs = 3, p = %.2f)" % g["p_use"])
        print("   valeur extrapolée (maillage infini) : %.5f" % g["phi_ext"])
        print("   incertitude numérique GCI : fin %.2f %%, moyen %.2f %%"
              % (100 * g["gci_fine"], 100 * g["gci_medium"]))
        if coef in ref:
            lo, mean, hi = ref[coef]
            print("   Ladson à %.2f° : %.5f (de %.5f à %.5f) -> écart extrapolé %+.1f %%"
                  % (alpha, mean, lo, hi, 100 * (g["phi_ext"] - mean) / mean))
        print()

    # ---------------- figure ----------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.grid": True, "grid.alpha": 0.3,
                         "axes.spines.top": False, "axes.spines.right": False})
    fig, axs = plt.subplots(1, 2, figsize=(13, 5.2))
    fig.suptitle(a.label, fontsize=13, fontweight="bold")
    colors = {"Cl": "#1f5fa8", "Cd": "#c0392b"}
    for ax, coef in zip(axs, ["Cl", "Cd"]):
        y = np.array(data[coef])
        g = results[coef]
        ax.plot(hn, y, "o-", color=colors[coef], ms=7, label="OpenFOAM (k-ω SST)")
        for x, v, nm, nc in zip(hn, y, names, cells):
            ax.annotate("%s\n%d k cellules" % (nm, round(nc / 1000)), (x, v),
                        textcoords="offset points", xytext=(8, 6), fontsize=8)
        if np.isfinite(g.get("p", np.nan)):
            ext = g["phi_ext"]
            ax.plot([0], [ext], "s", color="k", ms=7, label="extrapolation de Richardson")
            ax.errorbar([hn[2]], [y[2]], yerr=[g["gci_fine"] * abs(y[2])], fmt="none",
                        ecolor="k", capsize=5, label="incertitude GCI du maillage fin")
            # courbe de Richardson phi(h) = ext + C h^p passant par le maillage fin
            hh = np.linspace(0, hn[0] * 1.05, 100)
            C = (y[2] - ext) / (hn[2] ** g["p_use"])
            ax.plot(hh, ext + C * hh ** g["p_use"], "--", color="grey", lw=1,
                    label="loi en $h^{%.2f}$" % g["p_use"])
        if coef in ref:
            lo, mean, hi = ref[coef]
            ax.axhspan(lo, hi, color="#f0b429", alpha=0.25, label="Ladson (dispersion)")
            ax.axhline(mean, color="#b7791f", ls=":", lw=1)
        ax.set_xlim(-0.15, hn[0] * 1.25)
        ax.set_xlabel("taille de maille relative h / h$_{fin}$")
        ax.set_ylabel("$C_l$" if coef == "Cl" else "$C_d$")
        ax.set_title("Portance" if coef == "Cl" else "Traînée")
        ax.legend(fontsize=8, loc="best")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(a.out, dpi=140)
    print("Figure : %s\n" % os.path.abspath(a.out))


if __name__ == "__main__":
    main()
